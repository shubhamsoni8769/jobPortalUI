import { Component, OnInit, Inject } from '@angular/core';
// import { MatDialogRef,MAT_DIALOG_DATA } from "@angular/material";

@Component({
  selector: 'app-broadcast-cv',
  templateUrl: './broadcast-cv.component.html',
  styleUrls: ['./broadcast-cv.component.css']
})
export class BroadcastCVComponent implements OnInit {

  constructor(
    // private dialogRef:MatDialogRef<BroadcastCVComponent>,
    // @Inject(MAT_DIALOG_DATA) public data:any,
  ) { }

  ngOnInit(): void {
  }

}

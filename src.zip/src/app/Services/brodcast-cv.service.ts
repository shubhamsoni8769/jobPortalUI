import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { broadcastCVData } from '../Model/brodcastCVdata';

@Injectable({
  providedIn: 'root'
})
export class BrodcastCVService {
  public profileData:Subject<any>= new Subject();
  public broadcastData:broadcastCVData;
  constructor() { 

  }
  setBroadcastData(broadcastData:broadcastCVData){
    this.broadcastData=broadcastData;

  }

  getBroadcastData(){
    this.profileData.next(this.broadcastData)
    return this.profileData.asObservable();
  }
}

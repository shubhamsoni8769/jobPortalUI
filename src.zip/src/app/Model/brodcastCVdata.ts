export class broadcastCVData{
    name:any;
    email:any;
    phoneNo:any;
    location:any;
    jobFunction:any;
    expectedCTC:any;
    experienced:any;
    noticePeriod:any;
    resume:any;
    constructor(name,email,phoneNo,location,jobFunction,expectedCTC,experienced,noticePeriod,resume){
        this.name=name;
        this.email=email;
        this.phoneNo=phoneNo;
        this.location=location;
        this.jobFunction=jobFunction;
        this.expectedCTC=expectedCTC;
        this.experienced=experienced;
        this.noticePeriod=noticePeriod;
        this.resume=resume;
    }

}